import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Login.css'; // Using same styling as login
import { FaUser, FaEnvelope, FaLock } from 'react-icons/fa';

function Register() {
  const [username, setUsername] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('Buyer');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');

  const handleRegister = (e) => {
    e.preventDefault();

    if (!username || !email || !password || !role) {
      setError('All fields are required.');
      return;
    }

    const users = JSON.parse(localStorage.getItem('users')) || [];

    const userExists = users.find((user) => user.email === email);
    if (userExists) {
      setError('User already registered with this email.');
      return;
    }

    const newUser = { username, email, password, role };
    users.push(newUser);
    localStorage.setItem('users', JSON.stringify(users));

    setMessage('Registration successful! You can login now.');
    setUsername('');
    setEmail('');
    setPassword('');
    setRole('Buyer');
    setError('');
  };

  return (
    <div className="login-container">
      <form onSubmit={handleRegister} className="login-form">
        <h2 className="login-title">Register</h2>

        <div className="input-wrapper">
          <FaUser className="input-icon" />
          <input
            type="text"
            placeholder="Username"
            className="login-input"
            value={username}
            onChange={(e) => setUsername(e.target.value)}
            required
          />
        </div>

        <div className="input-wrapper">
          <FaEnvelope className="input-icon" />
          <input
            type="email"
            placeholder="Email"
            className="login-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        <div className="input-wrapper">
          <FaLock className="input-icon" />
          <input
            type="password"
            placeholder="Password"
            className="login-input"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
        </div>

        <select
          className="login-input"
          value={role}
          onChange={(e) => setRole(e.target.value)}
          required
        >
          <option value="Buyer">Buyer</option>
          <option value="Tenant">Tenant</option>
          <option value="Owner">Owner</option>
          <option value="Admin">Admin</option>
          <option value="Content Creator">Content Creator</option>
        </select>

        {error && <p className="login-error">{error}</p>}
        {message && <p style={{ color: 'lime' }}>{message}</p>}

        <button type="submit" className="login-button">Register</button>

        <p style={{ marginTop: '10px' }}>
          <Link to="/" style={{ color: 'lime' }}>Back to Login</Link>
        </p>
      </form>
    </div>
  );
}

export default Register;
