import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import './Login.css'; // Reuse same styling if consistent across auth pages
import { FaEnvelope } from 'react-icons/fa';

function ResetPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');

  const handleReset = (e) => {
    e.preventDefault();

    if (!email) {
      setMessage('Please enter your email.');
      return;
    }

    // Simulate reset logic
    const users = JSON.parse(localStorage.getItem('users')) || [];
    const userExists = users.some((user) => user.email === email);

    if (userExists) {
      setMessage('Reset link sent to your email!');
    } else {
      setMessage('Email not found. Please register.');
    }
  };

  return (
    <div className="login-container">
      <form onSubmit={handleReset} className="login-form">
        <h2 className="login-title">Forgot Password</h2>

        <div className="input-icon">
          <FaEnvelope className="icon" />
          <input
            type="email"
            placeholder="Enter your email"
            className="login-input"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
        </div>

        {message && <p className="login-error">{message}</p>}

        <button type="submit" className="login-button">
          Send Reset Link
        </button>

        <p style={{ marginTop: '20px' }}>
          <Link to="/" style={{ color: 'lime' }}>Back to Login</Link>
        </p>
      </form>
    </div>
  );
}

export default ResetPassword;
